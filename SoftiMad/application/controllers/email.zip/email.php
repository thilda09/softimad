<?php 

echo form_open('email.php', ['id'=>'frmUsers']);
echo form_input(['name' => 'user_id']);
echo form_input(['type' => 'email', 'name' => 'mail']);

$data = array (
    'name'=> 'commentaire',
    'rows'=> '5',
    'placeholder'=> '*Commentaire',
    'class'=> 'formulaire',
    'rules'=> 'required'
);
echo form_textarea($data);
echo form_submit('btnSubmit', 'Envoyer message');
echo form_close();

class Sendemail extends CI_Controller{
    function __construct() 
    {

        parent::Controller();
        $this->load->helper(array('form', 'url'));
        
    }
    function mail()
    {
        $this->load->view('index');
    }
     
    public function data_submited(){
        if ( isset( $_POST['submit'] ) ) {
            $nom = $_REQUEST['name'];
            $name = $_REQUEST['mail'];
            $this->load->library('form_validation'); 
            $this->form_validation->run();
        $this->load->view('index.php', $data);
        }       
    }

    function SendMail()
    {
       $config['protocol'] = "smtp";
       $config['smtp_host'] = "ssl://smtp.googlemail.com";
       $config['smtp_port'] = "465";
       $config['smtp_user'] = "ravaonirinam749@gmail.com";
       $config['smtp_pass'] = "thilde??1300";
       $config['validate'] = FALSE;
       $config['smtp_crypto'] = "ssl";
       $config['charset'] = "utf-8";
       $config['mailtype'] = "html";
       $config['newline'] = "\r\n";

        
        $this->load->library('email', $config);
        $this->email->set_newline("\r\n");

        $this->load->library('email', $config);
        $name = $this->input->post('form_name', TRUE);
        $email = $this->input->post('form_email', TRUE);
        $message = $this->input->post('form_message', TRUE);
        $this->email->from($email, 'Teste');
        $this->email->to('ravaonirinam749@gmail.com');
        $this->email->subject('test');
        $this->email->message('$data');

        $path = $this->config->item('server_root');
        $file = $path . '/softimad/SofftiMad/attachements/info.txt';

        $this->email->attach($file);

        if($this->email->send())
            {
                echo 'ton email est arrivé';
            }
        else 
            {
                show_error($this->email->print_debugger());
            }
    }
}

?> 